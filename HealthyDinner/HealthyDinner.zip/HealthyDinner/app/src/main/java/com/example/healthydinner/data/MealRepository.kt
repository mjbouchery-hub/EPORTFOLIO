package com.example.healthydinner.data

import android.util.Log
import com.example.healthydinner.BuildConfig
import com.example.healthydinner.api.RetrofitClient

class MealRepository(private val dao: MealDao) {

    fun getMeals(weekTag: String) = dao.getMealsForWeek(weekTag)

    suspend fun refreshMeals(weekTag: String) {
        try {
            Log.d("HealthyDinner", "API KEY = ${BuildConfig.SPOONACULAR_API_KEY}")

            val response = RetrofitClient.api.getRandomRecipes(
                number = 7,
                tags = "",
                apiKey = BuildConfig.SPOONACULAR_API_KEY
            )

            Log.d("HealthyDinner", "Response body: $response")
            Log.d("HealthyDinner", "Recipes returned = ${response.recipes.size}")

            val meals = response.recipes.mapIndexed { index, dto ->
                Meal(
                    title = dto.title,
                    imageUrl = dto.image,
                    summary = dto.summary ?: "",
                    instructions = dto.instructions ?: "No instructions provided.",
                    dayOfWeek = index,
                    weekTag = weekTag
                )
            }

            dao.deleteWeek(weekTag)
            dao.insertAll(meals)

            Log.d("HealthyDinner", "Meals saved to database = ${meals.size}")
        } catch (e: Exception) {
            Log.e("HealthyDinner", "Failed to refresh meals", e)
        }
    }
}