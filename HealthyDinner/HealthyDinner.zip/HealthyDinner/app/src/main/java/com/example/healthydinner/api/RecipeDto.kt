package com.example.healthydinner.api

data class RecipeResponse(
    val recipes: List<RecipeDto>
)

data class RecipeDto(
    val id: Int,
    val title: String,
    val image: String,
    val summary: String?,
    val instructions: String?,
    val extendedIngredients: List<IngredientDto>?
)

data class IngredientDto(
    val id: Int,
    val original: String
)
